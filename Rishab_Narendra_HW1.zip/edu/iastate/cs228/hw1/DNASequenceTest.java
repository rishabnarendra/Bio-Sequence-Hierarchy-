package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Test class to test the DNASequence class
 * @author RishabNarendra
 */
public class DNASequenceTest {

	/**
	 * Test length of the character array
	 */
	@Test
	public void testLength() {
		char[] a = { 'a', 'c', 'C' };
		DNASequence test = new DNASequence(a);
		assertEquals(3, test.seqLength());
	}

	/**
	 * Test if the characters passed are valid
	 */
	@Test
	public void testValidLetter() {
		char[] a = { 'a', 'c', 'C' };
		DNASequence test = new DNASequence(a);
		assertEquals(true, test.isValidLetter(a[0]));
		assertEquals(true, test.isValidLetter(a[1]));
		assertEquals(true, test.isValidLetter(a[2]));
	}
}
