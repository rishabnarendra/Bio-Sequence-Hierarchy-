package edu.iastate.cs228.hw1;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

/**
 * Tests the CodingDNASequence class
 * 
 * @author RishabNarendra
 */
public class CodingDNASequenceTest {

	/**
	 * Tests if the Sequence array has been translated properly
	 */
	@Test
	public void testTranslate() {
		char[] a = { 'A', 'T', 'G', 'A', 'A', 'A' };
		char[] b = { 'M', 'K' };
		CodingDNASequence test = new CodingDNASequence(a);
		assertEquals(Arrays.toString(b), Arrays.toString(test.translate()));
	}

	/**
	 * Tests if the Sequence array has been translated properly
	 */
	@Test
	public void testTranslate2() {
		char[] a = { 'A', 'T', 'G', 'A', 'A', 'A', 'T' };
		char[] b = { 'M', 'K' };
		CodingDNASequence test = new CodingDNASequence(a);
		assertEquals(Arrays.toString(b), Arrays.toString(test.translate()));
	}

	/**
	 * Tests if the start codon is correct
	 */
	@Test
	public void testCheckStartCodon() {
		char[] a = { 'A', 'T', 'G', 'A', 'A', 'A' };
		CodingDNASequence test = new CodingDNASequence(a);
		assertEquals(true, test.checkStartCodon());
	}

	/**
	 * Tests if the start codon is correct
	 */
	@Test
	public void testCheckStartCodon2() {
		char[] a = { 'A', 'T' };
		CodingDNASequence test = new CodingDNASequence(a);
		assertEquals(false, test.checkStartCodon());
	}
}
