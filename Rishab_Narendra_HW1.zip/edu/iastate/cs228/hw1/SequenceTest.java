package edu.iastate.cs228.hw1;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

/**
 * Test class to test the Sequence class
 * 
 * @author RishabNarendra
 */
public class SequenceTest {

	/**
	 * Tests length of the character array
	 */
	@Test
	public void testLength() {
		char[] a = { 'a', 'B', 'C' };
		Sequence test = new Sequence(a);
		assertEquals(3, test.seqLength());
	}

	/**
	 * Tests if the characters passed are valid
	 */
	@Test
	public void testValidLetter() {
		char[] a = { 'a', 'B', 'C' };
		Sequence test = new Sequence(a);
		assertEquals(true, test.isValidLetter(a[0]));
		assertEquals(true, test.isValidLetter(a[1]));
		assertEquals(true, test.isValidLetter(a[2]));
	}

	/**
	 * Tests if the Sequence has been converted to a String type correctly
	 */
	@Test
	public void testToString() {
		char[] a = { 'a', 'B', 'C' };
		Sequence test = new Sequence(a);
		assertEquals("aBC", test.toString());
	}

	/**
	 * Tests if the getSeq() method returns the same copy of the sequence array
	 */
	@Test
	public void testGetSeq() {
		char[] a = { 'a', 'B', 'C' };
		Sequence test = new Sequence(a);
		assertEquals(Arrays.toString(a), Arrays.toString(test.getSeq()));
	}
}
