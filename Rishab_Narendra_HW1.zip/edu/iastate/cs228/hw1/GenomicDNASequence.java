package edu.iastate.cs228.hw1;

/**
 * Subclass to class DNASequence which is a subclass to class Sequence
 * 
 * @author RishabNarendra
 */
public class GenomicDNASequence extends DNASequence {
	/**
	 * Boolean array that stores if the particular index is true or false
	 */
	private boolean[] iscoding;

	/**
	 * Constructor that invalidates each character and saves a copy if valid,
	 * else throws an exception
	 * 
	 * @param gdnaarr
	 *            Character array to be invalidated
	 */
	public GenomicDNASequence(char[] gdnaarr) {
		super(gdnaarr);
		iscoding = new boolean[gdnaarr.length];
		for (int j = 0; j < iscoding.length; j++)
			iscoding[j] = false;
	}

	/**
	 * Throws an error if first>last or first<0 or last>length
	 * 
	 * @param first
	 *            Starting position
	 * @param last
	 *            Ending position
	 */
	public void markCoding(int first, int last) {
		if (first > last || first < 0 || last >= seqLength())
			throw new IllegalArgumentException("Coding border is out of bound");
		else {
			for (int i = first; i <= last; i++)
				iscoding[i] = true;
		}
	}

	/**
	 * This method takes all the coding exons and concatenates them in order
	 * 
	 * @param exonpos
	 *            Specifies the start and end positions of the coding exons
	 * @return List of extracted characters
	 */
	public char[] extractExons(int[] exonpos) {
		int h = 0;
		for (int i = 0; i < exonpos.length; i++) {
			for (int j = exonpos[i]; j <= exonpos[i + 1]; j++) {
				h++;
			}
			i++;
		}
		char[] extracted = new char[h];
		if (exonpos.length == 0 || exonpos.length % 2 != 0)
			throw new IllegalArgumentException("Empty array or odd number of array elements");
		for (int j = 0; j < exonpos.length; j++)
			if (iscoding[exonpos[j]] == false)
				throw new IllegalStateException("Noncoding position is found");
		for (int i = 0; i < exonpos.length; i++)
			if (exonpos[i] < 0 || exonpos[i] >= seqLength())
				throw new IllegalArgumentException("Exon position is out of bound");
		for (int i = 0; i < exonpos.length - 1; i++)
			if (exonpos[i] > exonpos[i + 1])
				throw new IllegalArgumentException("Exon positions are not in order");
			else {
				int s = 0;
				for (int z = 0; z < exonpos.length; z++) {
					for (int a = exonpos[z]; a <= exonpos[z + 1]; a++) {
						extracted[s] = seqarr[a];
						s++;
					}
					z++;
				}
			}
		return extracted;
	}
}
