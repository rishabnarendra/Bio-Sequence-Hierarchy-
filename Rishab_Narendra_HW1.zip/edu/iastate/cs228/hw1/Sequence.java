package edu.iastate.cs228.hw1;

/**
 * Sequence class that represents the superclass to all classes
 * 
 * @author RishabNarendra
 */
public class Sequence {
	/**
	 * Character array storing sequence of characters
	 */
	protected char[] seqarr;

	/**
	 * Sequence class constructor that checks if all characters are valid else
	 * throws an IllegalArgumentException
	 * 
	 * @param sarr
	 *            Array of characters to be initialized to the seqarr character
	 *            array
	 */
	public Sequence(char[] sarr) {
		seqarr = new char[sarr.length];
		for (int i = 0; i < sarr.length; i++)
			if (isValidLetter(sarr[i]))
				seqarr[i] = sarr[i];
			else
				throw new IllegalArgumentException("Invalid Sequence letter for class " + super.getClass());
	}

	/**
	 * Returns length of the character array.
	 * 
	 * @return Length of character array
	 */
	public int seqLength() {
		return seqarr.length;
	}

	/**
	 * Creates a new copy of the character array and returns the copy
	 * 
	 * @return Copy of the character array
	 */
	public char[] getSeq() {
		char[] copy = new char[seqarr.length];
		for (int i = 0; i < copy.length; i++)
			copy[i] = seqarr[i];
		return copy;
	}

	/**
	 * Returns the string representation of the character array
	 * 
	 * @return String representation of the character array
	 */
	public String toString() {
		String seq = "";
		for (int i = 0; i < seqarr.length; i++)
			seq += seqarr[i];
		return seq;
	}

	/**
	 * This method compares the sequence of characters
	 * 
	 * @param obj
	 *            Object to be compared to
	 * @return True if sequence is same, case insensitive, false otherwise
	 */
	public boolean equals(Object obj) {
		if (!obj.equals(null) && obj.equals(seqarr))
			return true;
		else
			return false;
	}

	/**
	 * This method checks if the character passed is a valid character
	 * 
	 * @param let
	 *            Character to be checked
	 * @return true if character is uppercase or lowercase, false otherwise
	 */
	public boolean isValidLetter(char let) {
		if (Character.isUpperCase(let) || Character.isLowerCase(let))
			return true;
		else
			return false;
	}

}
