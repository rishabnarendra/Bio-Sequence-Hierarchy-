package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Test;

/**
 * Test class to test the GenomicDNASequence class
 * 
 * @author RishabNarendra
 */
public class GenomicDNASequenceTest {

	/**
	 * Test length of the character array
	 */
	@Test
	public void testLength() {
		char[] a = { 'a', 'c', 'T' };
		GenomicDNASequence test = new GenomicDNASequence(a);
		assertEquals(3, test.seqLength());
	}

	/**
	 * Test if the characters passed are valid
	 */
	@Test
	public void testValidLetter() {
		char[] a = { 'a', 'c', 'T' };
		GenomicDNASequence test = new GenomicDNASequence(a);
		assertEquals(true, test.isValidLetter(a[0]));
		assertEquals(true, test.isValidLetter(a[1]));
		assertEquals(true, test.isValidLetter(a[2]));
	}

	/**
	 * Tests if the extracted exons are correct
	 */
	@Test
	public void testExtractExons() {
		char[] a = { 'A', 'A', 'T', 'G', 'C', 'C', 'A', 'G', 'T', 'C', 'A', 'G', 'C', 'A', 'T', 'A', 'G', 'C', 'G', 'T',
				'A' };
		int[] exonpos = { 1, 5, 8, 10, 13, 16 };
		char[] b = { 'A', 'T', 'G', 'C', 'C', 'T', 'C', 'A', 'A', 'T', 'A', 'G' };
		GenomicDNASequence test = new GenomicDNASequence(a);
		test.markCoding(1, 16);
		assertEquals(Arrays.toString(b), Arrays.toString(test.extractExons(exonpos)));
	}
}
