package edu.iastate.cs228.hw1;

/**
 * Subclass to the class Sequence
 * 
 * @author RishabNarendra
 */
public class ProteinSequence extends Sequence {

	/**
	 * Constructor that invalidates each character and saves a copy if valid,
	 * else throws an exception
	 * 
	 * @param psarr
	 *            Character array to be invalidated
	 */
	public ProteinSequence(char[] psarr) {
		super(psarr);
	}

	/**
	 * Override method that checks if the character passed is valid
	 * 
	 * @param Character
	 *            to be checked
	 * @return Returns true if character is not b,j,o,u,x,z, else returns false
	 */
	@Override
	public boolean isValidLetter(char aa) {
		if (Character.toLowerCase(aa) != 'b' || Character.toLowerCase(aa) != 'j' || Character.toLowerCase(aa) != 'o'
				|| Character.toLowerCase(aa) != 'u' || Character.toLowerCase(aa) != 'x'
				|| Character.toLowerCase(aa) != 'z')
			return true;
		else
			return false;
	}
}
