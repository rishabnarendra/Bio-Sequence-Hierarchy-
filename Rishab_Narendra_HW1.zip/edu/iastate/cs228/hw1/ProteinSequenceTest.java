package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Test class to test the ProteinSequence class
 * @author RishabNarendra
 */
public class ProteinSequenceTest {

	/**
	 * Test length of the character array
	 */
	@Test
	public void testLength() {
		char[] a = { 'a', 'c', 'd' };
		ProteinSequence test = new ProteinSequence(a);
		assertEquals(3, test.seqLength());
	}

	/**
	 * Test if the characters passed are valid
	 */
	@Test
	public void testValidLetter() {
		char[] a = { 'a', 'c', 'd' };
		ProteinSequence test = new ProteinSequence(a);
		assertEquals(true, test.isValidLetter(a[0]));
		assertEquals(true, test.isValidLetter(a[1]));
		assertEquals(true, test.isValidLetter(a[2]));
	}
}
