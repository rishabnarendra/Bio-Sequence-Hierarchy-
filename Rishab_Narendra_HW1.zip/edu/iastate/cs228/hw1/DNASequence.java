package edu.iastate.cs228.hw1;

/**
 * Subclass to the class Sequence
 * 
 * @author RishabNarendra
 */
public class DNASequence extends Sequence {
	/**
	 * Constructor that invalidates each character and saves a copy if valid,
	 * else throws an exception
	 * 
	 * @param dnaarr
	 *            Character array to be invalidated
	 */
	public DNASequence(char[] dnaarr) {
		super(dnaarr);
	}

	/**
	 * Override method that checks if the character passed is valid
	 * 
	 * @param let
	 *            Character to be checked
	 * @return Returns true if character is a,c,g,t, case insensitive, else
	 *         returns false
	 */
	@Override
	public boolean isValidLetter(char let) {
		if (let == 'A' || let == 'a' || let == 'C' || let == 'c' || let == 'G' || let == 'g' || let == 'T'
				|| let == 't')
			return true;
		else
			return false;
	}
}
